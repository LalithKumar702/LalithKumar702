from tkinter import *
import datetime
import tkinter as tk
from datetime import date
import mysql.connector
from mysql.connector import Error
from pandas import DataFrame
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tkinter.ttk import Combobox

'''
3 databases for 3 categories i.e. mobiles, cars, laptops
mobDB
carDB
lapDB

Each of these databases can have n number of tables.
One table for each website.
Name of the table will be same as website name
Contents of the table -> NameOfTheProduct(Primary Key), PriceOfTheProduct, ddate

'''

def mainFun(usrname, pwd):
    try:
            flag = 0            # to check if the database is already present
            con = mysql.connector.connect(host='localhost', user=usrname, password=pwd) # connect to the mySql server
            cur = con.cursor(buffered = True)
            cur.execute("SHOW DATABASES")                 # get a list of all the databases present in the server
            for x in cur.fetchall():
                for y in x:
                    if y == 'mobdb':             # check if the required the database is present
                        flag = 1
                        break
            if flag != 1:                                   # if not present then create database and table and make a connection and cursor to it
                cur.execute("CREATE DATABASE mobdb")
                cur.execute("CREATE DATABASE cardb")
                cur.execute("CREATE DATABASE lapdb")
                mobcon = mysql.connector.connect(host='localhost', user=usrname, password=pwd, database='mobdb')
                mobcur = mobcon.cursor(buffered = True)
                carcon = mysql.connector.connect(host='localhost', user=usrname, password=pwd, database='cardb')
                carcur = carcon.cursor(buffered = True)
                lapcon = mysql.connector.connect(host='localhost', user=usrname, password=pwd, database='lapdb')
                lapcur = lapcon.cursor(buffered = True)

            else:                               # otherwise just connect to that database and create a cursor
                mobcon = mysql.connector.connect(host='localhost', user=usrname, password=pwd, database='mobdb')
                mobcur = mobcon.cursor(buffered = True)
                carcon = mysql.connector.connect(host='localhost', user=usrname, password=pwd, database='cardb')
                carcur = carcon.cursor(buffered = True)
                lapcon = mysql.connector.connect(host='localhost', user=usrname, password=pwd, database='lapdb')
                lapcur = lapcon.cursor(buffered = True)
            #   create a main window
            m = Tk(className="lalithPriceComparator")   # creating  main window
            m.configure(bg='cyan')
            m.geometry('400x360')

            def onClickHome():
                mainAddBtn.configure(state='normal', bg='yellow')
                mainEditBtn.configure(state='normal', bg='yellow')
                mainDelBtn.configure(state='normal', bg='yellow')
                mainHomeBtn.configure(state='disabled', bg='#3CAF50')
                delete_frame.place(x=-1000, y=-1000)
                edit_frame.place(x=-1000, y=-1000)
                add_frame.place(x=-1000, y=-1000)
                edit_website_frame.place(x=-1000, y=-1000)
                edit_record_frame.place(x=-1000, y=-1000)
                add_new_record_frame.place(x=-1000, y=-1000)
                delete_record_frame.place(x=-1000, y=-1000)
                home_frame.place(x=10, y=30)
            def onClickAdd():
                mainHomeBtn.configure(state='normal', bg='yellow')
                mainEditBtn.configure(state='normal', bg='yellow')
                mainDelBtn.configure(state='normal', bg='yellow')
                mainAddBtn.configure(state='disabled', bg='#3CAF50')
                delete_frame.place(x=-1000, y=-1000)
                edit_frame.place(x=-1000, y=-1000)
                home_frame.place(x=-1000, y=-1000)
                add_new_record_frame.place(x=-1000, y=-1000)
                delete_record_frame.place(x=-1000, y=-1000)
                edit_website_frame.place(x=-1000, y=-1000)
                edit_record_frame.place(x=-1000, y=-1000)
                add_frame.place(x=10, y=30)
            def onClickEdit():
                mainHomeBtn.configure(state='normal', bg='yellow')
                mainAddBtn.configure(state='normal', bg='yellow')
                mainDelBtn.configure(state='normal', bg='yellow')
                mainEditBtn.configure(state='disabled', bg='#3CAF50')
                add_frame.place(x=-1000, y=-1000)
                delete_frame.place(x=-1000, y=-1000)
                home_frame.place(x=-1000, y=-1000)
                add_new_record_frame.place(x=-1000, y=-1000)
                delete_record_frame.place(x=-1000, y=-1000)
                edit_website_frame.place(x=-1000, y=-1000)
                edit_record_frame.place(x=-1000, y=-1000)
                edit_frame.place(x=10, y=30)
            def onClickDelete():
                mainHomeBtn.configure(state='normal', bg='yellow')
                mainAddBtn.configure(state='normal', bg='yellow')
                mainEditBtn.configure(state='normal', bg='yellow')
                mainDelBtn.configure(state='disabled', bg='#3CAF50')
                edit_frame.place(x=-1000, y=-1000)
                home_frame.place(x=-1000, y=-1000)
                add_frame.place(x=-1000, y=-1000)
                add_new_record_frame.place(x=-1000, y=-1000)
                delete_record_frame.place(x=-1000, y=-1000)
                edit_website_frame.place(x=-1000, y=-1000)
                edit_record_frame.place(x=-1000, y=-1000)
                delete_frame.place(x=10, y=30)

            mainHomeBtn = Button(m, text='Home', width=8, state='disabled', bg='#3CAF50', command=onClickHome)
            mainHomeBtn.grid(row=1, column=0)
            mainAddBtn  = Button(m, text='Add', width=8, bg='yellow', command=onClickAdd)
            mainAddBtn.grid(row=1, column=1)
            mainEditBtn = Button(m, text='Edit', width=8, bg='yellow', command=onClickEdit)
            mainEditBtn.grid(row=1, column=2)
            mainDelBtn  = Button(m, text='Delete', width=8, bg='yellow', command=onClickDelete)
            mainDelBtn.grid(row=1, column=3)

            common_columns_website = "(nameOfProduct varchar(50) PRIMARY KEY, price INT, ddate varchar(15))"

            # -------------------------- frames ---------------------------------------------------
            home_frame = LabelFrame(m, width=380, height=320, bg='#ccffff')
            home_frame.place(x=10, y=30)
            add_frame = LabelFrame(m, width=380, height=320, bg='#ffd9b3')
            edit_frame = LabelFrame(m, width=380, height=320, bg='#ecc6c6')
            delete_frame = LabelFrame(m, width=380, height=320, bg='#e0ccff')

            def displayMessage(message):    # a message box / can be used to display error or display message or tips and many more...
                messageDisplayer = Tk(className="message box")
                messageDisplayer.configure(bg='black')
                messageDisplayer.geometry('600x80')

                textArea = Label(messageDisplayer, text=message, anchor='w', bg='yellow', fg='red', font='time 16 bold')
                textArea.place(x=60, y=2)
                Button(messageDisplayer, text='OK', bg='green', fg='yellow', width=10, command=messageDisplayer.destroy).place(x=150, y=50)  # destroy the window if user presses okay button
            # -------------------------------------- ADD FRAME ---------------------------------------------

            def add_new_mob_website(name_of_website):
                mobcur.execute("SHOW TABLES")
                result = mobcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 1:
                    message = "Website already present"
                    displayMessage(message)
                    return

                query = "CREATE TABLE " + name_of_website + common_columns_website
                mobcur.execute(query)
                mobcon.commit()

                message = "Website sucessfully added!"
                displayMessage(message)
            def add_new_car_website(name_of_website):
                carcur.execute("SHOW TABLES")
                result = carcur.fetchall()
                flag = 0

                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 1:
                    message = "Website already present"
                    displayMessage(message)
                    return

                query = "CREATE TABLE " + name_of_website + common_columns_website
                carcur.execute(query)
                carcon.commit()

                message = "Website sucessfully added!"
                displayMessage(message)
            def add_new_lap_website(name_of_website):
                lapcur.execute("SHOW TABLES")
                result = lapcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 1:
                    message = "Website already present"
                    displayMessage(message)
                    return

                query = "CREATE TABLE " + name_of_website + common_columns_website
                lapcur.execute(query)
                lapcon.commit()

                message = "Website sucessfully added!"
                displayMessage(message)
            def add_new_website():
                category = combo_box_add.get()
                name_of_website = name_of_website_add.get()
                name_of_website_add.delete(0, END)
                if not name_of_website or not category:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    add_new_mob_website(name_of_website)

                elif category == 'Laptop':
                    add_new_lap_website(name_of_website)
                else:
                    add_new_car_website(name_of_website)
            def check_new_mob_record_website(name_of_website):
                mobcur.execute("SHOW TABLES")
                result = mobcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    name_of_website_add.delete(0, END)
                    return
                add_new_record_frame.place(x=10, y=30)
            def check_new_lap_record_website(name_of_website):
                lapcur.execute("SHOW TABLES")
                result = lapcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    name_of_website_add.delete(0, END)
                    return
                add_new_record_frame.place(x=10, y=30)
            def check_new_car_record_website(name_of_website):
                carcur.execute("SHOW TABLES")
                result = carcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    name_of_website_add.delete(0, END)
                    return
                add_new_record_frame.place(x=10, y=30)
            def add_new_record():
                category = combo_box_add.get()
                name_of_website = name_of_website_add.get()
                if not name_of_website or not category:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    check_new_mob_record_website(name_of_website)

                elif category == 'Laptop':
                    check_new_lap_record_website(name_of_website)
                else:
                    check_new_car_record_website(name_of_website)
            def add_new_car_record_website(name_of_website):
                item_name = name_add_record_frame.get()
                if price_add_record_frame.get() == '':
                    item_price = 0
                else:
                    item_price = int(price_add_record_frame.get())

                if not item_name or not item_price:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                values = (item_name,)
                carcur.execute(query, values)
                carcon.commit()
                result = carcur.fetchall()

                if result:
                    message = "Product already present in the website database"
                    displayMessage(message)
                    return

                item_date = date.today()
                query = "INSERT INTO " + name_of_website + " VALUES(%s, %s, %s)"
                values = (item_name, item_price, item_date)
                carcur.execute(query, values)
                carcon.commit()
                message = "Record entered sucessfully"
                displayMessage(message)
            def add_new_lap_record_website(name_of_website):
                item_name = name_add_record_frame.get()
                if price_add_record_frame.get() == '':
                    item_price = 0
                else:
                    item_price = int(price_add_record_frame.get())

                if not item_name or not item_price:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return
                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                values = (item_name,)
                lapcur.execute(query, values)
                lapcon.commit()
                result = mobcur.fetchall()

                if result:
                    message = "Product already present in the website database"
                    displayMessage(message)
                    return

                item_date = date.today()
                query = "INSERT INTO " + name_of_website + " VALUES(%s, %s, %s)"
                values = (item_name, item_price, item_date)
                lapcur.execute(query, values)
                lapcon.commit()
                message = "Record entered sucessfully"
                displayMessage(message)
            def add_new_mob_record_website(name_of_website):
                item_name = name_add_record_frame.get()
                if price_add_record_frame.get() == '':
                    item_price = 0
                else:
                    item_price = int(price_add_record_frame.get())

                if not item_name or not item_price:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                values = (item_name,)
                mobcur.execute(query, values)
                mobcon.commit()
                result = mobcur.fetchall()

                if result:
                    message = "Product already present in the website database"
                    displayMessage(message)
                    return

                item_date = date.today()
                query = "INSERT INTO " + name_of_website + " VALUES(%s, %s, %s)"
                values = (item_name, item_price, item_date)
                mobcur.execute(query, values)
                mobcon.commit()
                message = "Record entered sucessfully"
                displayMessage(message)
            def submit_add_new_record_frame():
                category = combo_box_add.get()
                name_of_website = name_of_website_add.get()

                if category == 'Mobile':
                    add_new_mob_record_website(name_of_website)

                elif category == 'Laptop':
                    add_new_lap_record_website(name_of_website)
                else:
                    add_new_car_record_website(name_of_website)

      #     xxxxxxxxxxxxxxx  frame for entering new record details  xxxxxxxxxxxxxxxxxx
            add_new_record_frame = LabelFrame(m, width=380, height=320, bg='#b3b3ff')
            Label(add_new_record_frame, text='Name', font="time 12 bold", bg='#b3b3ff').place(x=60, y=20)
            Label(add_new_record_frame, text='Price', font="time 12 bold", bg='#b3b3ff').place(x=60, y=50)
            name_add_record_frame = Entry(add_new_record_frame, width=25)
            price_add_record_frame = Entry(add_new_record_frame, width = 25)
            name_add_record_frame.place(x=160, y=20)
            price_add_record_frame.place(x=160, y=50)
            submit_add_record_frame = Button(add_new_record_frame, text='submit', bg='#3CAF50', width=12, command=submit_add_new_record_frame)
            submit_add_record_frame.place(x=150, y=100)

            Label(add_frame, text='Select Category', font="time 12 bold", bg='#ffd9b3').place(x=110, y=20)
            data_combo_add=("Mobile", "Car", "Laptop")
            combo_box_add = Combobox(add_frame, values=data_combo_add, state='readonly')
            combo_box_add.place(x=110, y=50)

            Label(add_frame, text='Enter Website Name', font="time 12 bold", bg='#ffd9b3').place(x=100, y=90)
            name_of_website_add = Entry(add_frame, width=40)
            name_of_website_add.place(x=65, y=120)

            add_website_add_frame = Button(add_frame, text='Add this website', width=24, bg='orange', command=add_new_website)
            add_record_add_frame  = Button(add_frame, text='Add new record in this website', width=24, bg='orange', command=add_new_record)

            add_website_add_frame.place(x=10, y=170)
            add_record_add_frame.place(x=190, y=170)

            # ############################################### ADD FRAME ##############################################

            # -------------------------------------- EDIT FRAME --------------------------------------------

            def check_edit_car_website(name_of_website):
                carcur.execute("SHOW TABLES")
                result = carcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    name_of_website_add.delete(0, END)
                    return
                edit_website_frame.place(x=10, y=30)
            def check_edit_lap_website(name_of_website):
                lapcur.execute("SHOW TABLES")
                result = lapcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    name_of_website_add.delete(0, END)
                    return
                edit_new_record_frame.place(x=10, y=30)
            def check_edit_mob_website(name_of_website):
                mobcur.execute("SHOW TABLES")
                result = mobcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    return
                edit_website_frame.place(x=10, y=30)
            def check_edit_car_website_data(name_of_website):
                carcur.execute("SHOW TABLES")
                result = carcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    name_of_website_add.delete(0, END)
                    return
                edit_record_frame.place(x=10, y=30)
            def check_edit_lap_website_data(name_of_website):
                lapcur.execute("SHOW TABLES")
                result = lapcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    name_of_website_add.delete(0, END)
                    return
                edit_record_frame.place(x=10, y=30)
            def check_edit_mob_website_data(name_of_website):
                mobcur.execute("SHOW TABLES")
                result = mobcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    name_of_website_add.delete(0, END)
                    return
                edit_record_frame.place(x=10, y=30)
            def edit_website():
                category = combo_box_edit.get()
                name_of_website = name_of_website_edit.get()
                if not name_of_website or not category:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    check_edit_mob_website(name_of_website)

                elif category == 'Laptop':
                    check_edit_lap_website(name_of_website)
                else:
                    check_edit_car_website(name_of_website)
            def edit_website_data():
                category = combo_box_edit.get()
                name_of_website = name_of_website_edit.get()
                if not name_of_website or not category:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    check_edit_mob_website_data(name_of_website)

                elif category == 'Laptop':
                    check_edit_lap_website_data(name_of_website)
                else:
                    check_edit_car_website_data(name_of_website)
            def check_mob_table(name_of_website):
                mobcur.execute("SHOW TABLES")
                result = mobcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 1:
                    return 1
                return 0
            def check_car_table(name_of_website):
                carcur.execute("SHOW TABLES")
                result = carcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 1:
                    return 1
                return 0
            def check_lap_table(name_of_website):
                lapcur.execute("SHOW TABLES")
                result = lapcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 1:
                    return 1
                return 0
            def submit_update_website_name():
                category = combo_box_edit.get()
                cur_name = name_of_website_edit.get()
                new_name = name_edit_website_frame.get()
                if not new_name:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    flag = check_mob_table(new_name)
                elif category == 'Laptop':
                    flag = check_lap_table(new_name)
                else:
                    flag = check_car_table(new_name)


                query = "ALTER TABLE " + cur_name +  " RENAME TO " + new_name.lower()
                if category == 'Mobile':
                    mobcur.execute(query,)
                    mobcon.commit()
                    if flag == 0:
                        message = "Website name changed sucessfully"
                        displayMessage(message)
                        return
                    if flag == 1:
                        message = "Entered name already present in the database"
                        displayMessage(message)
                        return
                elif category == 'Laptop':
                    lapcur.execute(query,)
                    lapcon.commit()
                    if flag == 0:
                        message = "Website name changed sucessfully"
                        displayMessage(message)
                        return
                    if flag == 1:
                        message = "Entered name already present in the database"
                        displayMessage(message)
                        return
                else:
                    carcur.execute(query,)
                    carcon.commit()
                    if flag == 0:
                        message = "Website name changed sucessfully"
                        displayMessage(message)
                        return
                    if flag == 1:
                        message = "Entered name already present in the database"
                        displayMessage(message)
                        return

            def edit_mob_data(name_of_website, cur_name, update_name, update_price):
                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                mobcur.execute(query, (cur_name,))
                result = mobcur.fetchall()

                if update_name:
                    query = "UPDATE " + name_of_website + " SET nameOfProduct = %s WHERE nameOfProduct = %s;"
                    values = (update_name, cur_name)
                    mobcur.execute(query)
                    mobcon.commit()
                if update_price:
                    query = "UPDATE " + name_of_website + " SET price = %s WHERE nameOfProduct = %s"
                    values = (update_price, cur_name)
                if result:
                    message = "Entered name already present"
                    displayMessage(message)
                    return
                    mobcur.execute(query, values)
                    mobcon.commit()
                else:
                    message = "Product details updated sucessfully"
                    displayMessage(message)
            def edit_car_data(name_of_website, cur_name, update_name, update_price):
                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                carcur.execute(query, (cur_name,))
                result = carcur.fetchall()

                if update_name:
                    query = "UPDATE " + name_of_website + " SET nameOfProduct = %s WHERE nameOfProduct = %s"
                    values = (update_name, cur_name)
                    carcur.execute(query, values)
                    carcon.commit()
                if update_price:
                    query = "UPDATE " + name_of_website + " SET price = %s WHERE nameOfProduct = %s"
                    values = (update_price, cur_name)
                    carcur.execute(query)
                    carcon.commit()
                if result:
                    message = "Entered name already present"
                    displayMessage(message)
                    return
                else:
                    message = "Product details updated sucessfully"
                    displayMessage(message)
            def edit_lap_data(name_of_website, cur_name, update_name, update_price):
                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                lapcur.execute(query)
                result = lapcur.fetchall()

                if update_name:
                    query = "UPDATE " + name_of_website + " SET nameOfProduct = %s WHERE nameOfProduct = %s"
                    lapcur.execute(query)
                    lapcon.commit()
                if update_price:
                    query = "UPDATE " + name_of_website + " SET price = %s WHERE nameOfProduct = %s"
                    lapcur.execute(query)
                    lapcon.commit()
                if result:
                    message = "Entered name already present"
                    displayMessage(message)
                    return
                else:
                    message = "Product details updated sucessfully"
                    displayMessage(message)
            def submit_update_website_record():
                category = combo_box_edit.get()
                name_of_website = name_of_website_edit.get()
                cur_name = name_edit_record_frame.get()
                update_name = update_name_edit_record_frame.get()
                if price_edit_record_frame.get() == '':
                    update_price = 0
                else:
                    update_price = int(price_edit_record_frame.get())

                if not update_name and not update_price:
                    message = "Please enter at least one field"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    print('aaya')
                    edit_mob_data(name_of_website, cur_name, update_name, update_price)

                elif category == 'Laptop':
                    edit_lap_data(name_of_website, cur_name, update_name, update_price)
                else:
                    edit_car_data(name_of_website, cur_name, update_name, update_price)

            edit_website_frame = LabelFrame(m, width=380, height=320, bg='#b3b3ff')
            Label(edit_website_frame, text='Update Name', font="time 12 bold", bg='#b3b3ff').place(x=140, y=20)
            name_edit_website_frame = Entry(edit_website_frame, width=25)
            name_edit_website_frame.place(x=120, y=50)
            submit_edit_website_frame = Button(edit_website_frame, text='submit', bg='#3CAF50', width=12, command=submit_update_website_name)
            submit_edit_website_frame.place(x=140, y=100)

            edit_record_frame = LabelFrame(m, width=380, height=320, bg='#b3b3ff')
            Label(edit_record_frame, text='Enter name of product to be edited', font="time 12 bold", bg='#b3b3ff').place(x=60, y=20)
            Label(edit_record_frame, text='Update Name', font="time 12 bold", bg='#b3b3ff').place(x=130, y=80)
            Label(edit_record_frame, text='Update Price', font="time 12 bold", bg='#b3b3ff').place(x=130, y=140)
            name_edit_record_frame = Entry(edit_record_frame, width=25)
            update_name_edit_record_frame = Entry(edit_record_frame, width=25)
            price_edit_record_frame = Entry(edit_record_frame, width = 25)
            name_edit_record_frame.place(x=120, y=50)
            update_name_edit_record_frame.place(x=120, y=110)
            price_edit_record_frame.place(x=120, y=170)
            submit_edit_record_frame = Button(edit_record_frame, text='submit', bg='#3CAF50', width=12, command=submit_update_website_record)
            submit_edit_record_frame.place(x=140, y=220)

            Label(edit_frame, text='Select Category', font="time 12 bold", bg='#ecc6c6').place(x=110, y=20)
            data_combo_edit=("Mobile", "Car", "Laptop")
            combo_box_edit = Combobox(edit_frame, values=data_combo_add, state='readonly')
            combo_box_edit.place(x=110, y=50)

            Label(edit_frame, text='Enter Website Name', font="time 12 bold", bg='#ecc6c6').place(x=100, y=90)
            name_of_website_edit = Entry(edit_frame, width=40)
            name_of_website_edit.place(x=65, y=120)

            add_website_edit_frame = Button(edit_frame, text='Edit this website', width=24, bg='#c65353', fg='white', command=edit_website)
            add_record_edit_frame  = Button(edit_frame, text='Edit record in this website', width=24, bg='#c65353', fg='white', command=edit_website_data)

            add_website_edit_frame.place(x=10, y=170)
            add_record_edit_frame.place(x=190, y=170)

            # $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ EDIT FRAME $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

            # -------------------------------------- DELETE FRAME ------------------------------------------
            # delete mobile website
            def delete_mob_website(name_of_website):
                mobcur.execute("SHOW TABLES")
                result = mobcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    return

                query = "DROP TABLE " + name_of_website
                mobcur.execute(query)
                mobcon.commit()

                message = "Website sucessfully deleted"
                displayMessage(message)
            # delete car website
            def delete_car_website(name_of_website):
                carcur.execute("SHOW TABLES")
                result = carcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    return

                query = "DROP TABLE " + name_of_website
                carcur.execute(query)
                carcon.commit()

                message = "Website sucessfully deleted"
                displayMessage(message)
            # delete laptop website
            def delete_lap_website(name_of_website):
                lapcur.execute("SHOW TABLES")
                result = lapcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    message = "Website not present"
                    displayMessage(message)
                    return

                query = "DROP TABLE " + name_of_website
                lapcur.execute(query)
                lapcon.commit()

                message = "Website sucessfully deleted"
                displayMessage(message)
            # delete website
            def delete_website():
                category = combo_box_delete.get()
                name_of_website = name_of_website_delete.get()
                combo_box_delete.delete(0, END)
                name_of_website_delete.delete(0, END)
                if not name_of_website or not category:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    delete_mob_website(name_of_website)

                elif category == 'Laptop':
                    delete_lap_website(name_of_website)
                else:
                    delete_car_website(name_of_website)
            def check_delete_mob_record_website(name_of_website):
                mobcur.execute("SHOW TABLES")
                result = mobcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    name_of_website_delete.delete(0, END)
                    message = "Website not present"
                    displayMessage(message)
                    return
                delete_record_frame.place(x=10, y=30)
            def check_delete_lap_record_website(name_of_website):
                lapcur.execute("SHOW TABLES")
                result = lapcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    name_of_website_delete.delete(0, END)
                    message = "Website not present"
                    displayMessage(message)
                    return
                delete_record_frame.place(x=10, y=30)
            def check_delete_car_record_website(name_of_website):
                carcur.execute("SHOW TABLES")
                result = carcur.fetchall()
                flag = 0
                for x in result:
                    for y in x:
                        if name_of_website.lower() == y:
                            flag = 1
                            break
                if flag == 0:
                    name_of_website_delete.delete(0, END)
                    message = "Website not present"
                    displayMessage(message)
                    return
                delete_record_frame.place(x=10, y=30)
            def delete_website_record():
                category = combo_box_delete.get()
                name_of_website = name_of_website_delete.get()
                if not name_of_website or not category:
                    name_of_website_delete.delete(0, END)
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    check_delete_mob_record_website(name_of_website)

                elif category == 'Laptop':
                    check_delete_lap_record_website(name_of_website)
                else:
                    check_delete_car_record_website(name_of_website)
            def delete_mob_record_website(name_of_website):
                item_name = name_delete_record_frame.get()
                if not item_name:
                    message = "Please enter name"
                    displayMessage(message)
                    return
                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                values = (item_name,)
                mobcur.execute(query, values)
                result = mobcur.fetchall()

                if not result:
                    message = "Item is not present in the database"
                    displayMessage(message)
                    return

                query = "DELETE FROM " + name_of_website + " WHERE nameOfProduct  = %s"
                mobcur.execute(query, values)
                mobcon.commit()

                message = "Deletion completed"
                displayMessage(message)
            def delete_lap_record_website(name_of_website):
                item_name = name_delete_record_frame.get()
                if not item_name:
                    message = "Please enter name"
                    displayMessage(message)
                    return
                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                values = (item_name,)
                lapcur.execute(query, values)
                result = lapcur.fetchall()

                if not result:
                    message = "Item is not present in the database"
                    displayMessage(message)
                    return

                query = "DELETE FROM " + name_of_website + " WHERE nameOfProduct  = %s"
                lapcur.execute(query, values)
                lapcon.commit()

                message = "Deletion completed"
                displayMessage(message)
            def delete_car_record_website(name_of_website):
                item_name = name_delete_record_frame.get()
                if not item_name:
                    message = "Please enter name"
                    displayMessage(message)
                    return
                query = "SELECT * FROM " + name_of_website + " WHERE nameOfProduct = %s"
                values = (item_name,)
                carcur.execute(query, values)
                result = carcur.fetchall()

                if not result:
                    message = "Item is not present in the database"
                    displayMessage(message)
                    return

                query = "DELETE FROM " + name_of_website + " WHERE nameOfProduct  = %s"
                carcur.execute(query, values)
                carcon.commit()

                message = "Deletion completed"
                displayMessage(message)
            def submit_delete_new_record_frame():
                category = combo_box_delete.get()
                name_of_website = name_of_website_delete.get()

                if not category or not name_of_website:
                    message = "Please enter name"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    delete_mob_record_website(name_of_website)

                elif category == 'Laptop':
                    delete_lap_record_website(name_of_website)
                else:
                    delete_car_record_website(name_of_website)

      #     xxxxxxxxxxxxxxx  frame for entering record details for deleting  xxxxxxxxxxxxxxxxxx
            delete_record_frame = LabelFrame(m, width=380, height=320, bg='#b3b3ff')
            Label(delete_record_frame, text='Name', font="time 12 bold", bg='#b3b3ff').place(x=60, y=20)
            name_delete_record_frame = Entry(delete_record_frame, width=25)
            name_delete_record_frame.place(x=160, y=20)
            submit_delete_record_frame = Button(delete_record_frame, text='submit', bg='#3CAF50', width=12, command=submit_delete_new_record_frame)
            submit_delete_record_frame.place(x=150, y=100)

            Label(delete_frame, text='Select Category', font="time 12 bold", bg='#e0ccff').place(x=110, y=20)
            data_combo_delete=("Mobile", "Car", "Laptop")
            combo_box_delete = Combobox(delete_frame, values=data_combo_add, state='readonly')
            combo_box_delete.place(x=110, y=50)

            Label(delete_frame, text='Enter Website Name', font="time 12 bold", bg='#e0ccff').place(x=100, y=90)
            name_of_website_delete = Entry(delete_frame, width=40)
            name_of_website_delete.place(x=65, y=120)

            add_website_delete_frame = Button(delete_frame, text='Delete this website', width=24, bg='#944dff', fg='white', command=delete_website)
            add_record_delete_frame  = Button(delete_frame, text='Delete record in this website', width=24, bg='#944dff', fg='white', command=delete_website_record)

            add_website_delete_frame.place(x=10, y=170)
            add_record_delete_frame.place(x=190, y=170)

            # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ DELETE FRAME @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

            # -------------------------------------- HOME FRAME --------------------------------------------
            productList = []
            websiteList = []

            def showStats(name_of_product):
                root= tk.Tk()           # create a new window to show the graphs
                root.geometry('1366x768')
                Label(root, text=name_of_product, font='time 22 bold', bg='cyan').place(x=600, y=20)
                rateList = []
                for x in productList:
                    for y in x:
                        rateList.append(y[1])

                data1 = {'Website': websiteList,                                      # provide the data for graphs 1
                 'Price': rateList
                }
                df1 = DataFrame(data1,columns=['Website','Price'])

                lowest_index = -1
                highest_index = -1
                lowest_price = min(rateList)
                highest_price = max(rateList)

                for x in range(0, len(rateList)):
                    if rateList[x] == lowest_price:
                        lowest_index = x
                    if rateList[x] == highest_price:
                        highest_index = x

                Label(root, text='Best website to purchase :', font='time 14 bold').place(x=800, y=80)
                Label(root, text='Worst website to purchase :', font='time 14 bold').place(x=800, y=120)

                Label(root, text=websiteList[lowest_index], font='time 14 bold', fg='red').place(x=1070, y=80)
                Label(root, text=websiteList[highest_index], font='time 14 bold', fg='red').place(x=1070, y=120)

                # graph 1
                figure1 = plt.Figure(figsize=(6,5), dpi=100)
                ax1 = figure1.add_subplot(111)
                bar1 = FigureCanvasTkAgg(figure1, root)
                bar1.get_tk_widget().pack(side=tk.LEFT)
                df1 = df1[['Website','Price']].groupby('Website').sum()
                df1.plot(kind='bar', legend=True, ax=ax1)
                ax1.set_title('Website vs Price')

                root.mainloop()

            def find_laptop(name_of_product):
                productList = []
                websiteList = []
                lapcur.execute("SHOW TABLES")
                result = lapcur.fetchall()
                for x in result:
                    for y in x:
                        query = "SELECT * FROM " + y + " WHERE nameOfProduct = %s"
                        values = (name_of_product,)
                        lapcur.execute(query, values)
                        ret_data = lapcur.fetchall()
                        if ret_data:
                            productList.append(ret_data)
                            websiteList.append(y)
                if websiteList == []:
                    message = "Product was not found on any website"
                    displayMessage(message)
                else:
                    showStats(name_of_product)

                print(productList, '\t', websiteList)
            def find_mobile(name_of_product):
                productList.clear()
                websiteList.clear()
                mobcur.execute("SHOW TABLES")
                result = mobcur.fetchall()
                for x in result:
                    for y in x:
                        query = "SELECT * FROM " + y + " WHERE nameOfProduct = %s"
                        values = (name_of_product,)
                        mobcur.execute(query, values)
                        ret_data = mobcur.fetchall()
                        if ret_data:
                            productList.append(ret_data)
                            websiteList.append(y)
                if websiteList == []:
                    message = "Product was not found on any website"
                    displayMessage(message)
                else:
                    showStats(name_of_product)
            def find_car(name_of_product):
                productList = []
                websiteList = []
                carcur.execute("SHOW TABLES")
                result = carcur.fetchall()
                for x in result:
                    for y in x:
                        query = "SELECT * FROM " + y + " WHERE nameOfProduct = %s"
                        values = (name_of_product,)
                        carcur.execute(query, values)
                        ret_data = carcur.fetchall()
                        if ret_data:
                            productList.append(ret_data)
                            websiteList.append(y)
                if websiteList == []:
                    message = "Product was not found on any website"
                    displayMessage(message)
                else:
                    showStats(name_of_product)
            def home_search_button():
                category = combo_box_home.get()
                name_of_product = name_of_product_home.get()

                if not name_of_product or not category:
                    message = "Please enter all fields"
                    displayMessage(message)
                    return

                if category == 'Mobile':
                    find_mobile(name_of_product)

                elif category == 'Laptop':
                    find_laptop(name_of_product)
                else:
                    find_car(name_of_product)

            Label(home_frame, text='Name of the product', font="time 14 bold", bg='#ccffff').place(x=95, y=20)
            name_of_product_home = Entry(home_frame, width=40)
            name_of_product_home.place(x=70, y=50)

            Label(home_frame, text='Select Category', font="time 14 bold", bg='#ccffff').place(x=115, y=90)
            data_combo_home=("Mobile", "Car", "Laptop")
            combo_box_home = Combobox(home_frame, values=data_combo_home, state='readonly')
            combo_box_home.place(x=120, y=120)

            search_home_button = Button(home_frame, text='Search', width = 8, bg = '#007a99', fg='white', command=home_search_button)
            search_home_button.place(x=155, y=160)

         # ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ HOME FRAME ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

            m.mainloop()

    except Error as err:    # print the error
            print(err)
    finally:
            if con.is_connected():  # close the connection after the task is done
                cur.close()
                con.close()
                print('connection is closed')
            if mobcon.is_connected():  # close the connection after the task is done
                mobcur.close()
                mobcon.close()
            if carcon.is_connected():  # close the connection after the task is done
                carcur.close()
                carcon.close()
            if lapcon.is_connected():  # close the connection after the task is done
                lapcur.close()
                lapcon.close()
            if mobcon.is_connected():  # close the connection after the task is done
                lapcur.close()
                lapcon.close()
def getStarted():       # on user click submit in admin windows this function will be called
    pwd = pswd.get()    # get the username and password entered by the user
    usrname = usrnm.get()
    if not usrname:     # use root as username if user doesnt enter username
        usrname = 'root'
    login.destroy()     # destroy the admin window
    mainFun(usrname, pwd)      # call the main function

# create a window for logging in
login= Tk(className="Login")
login.configure(bg='green')
login.geometry('370x90')
Label(login, text='Username (default:root) ', font ='time 10 bold', width = 20, anchor='w', bg='yellow').grid(row=1, column=2)
Label(login, text='Password', font ='time 10 bold', width = 20, anchor='w', bg='yellow').grid(row=2, column=2)
usrnm=Entry(login, width=30)
usrnm.grid(row=1, column=3, padx=10, pady=5)
pswd=Entry(login, width=30)
pswd.grid(row=2, column=3, padx=10, pady=5)
Button(login, text = 'submit', command = getStarted, width = 10, bg='orange').place(x=140, y=60)        # button to submit
login.mainloop()
